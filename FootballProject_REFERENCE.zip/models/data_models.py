
from dataclasses import dataclass
@dataclass
class Match:
    date:str; home:str; away:str; home_goals:int; away_goals:int
