
import requests
from bs4 import BeautifulSoup
from models.data_models import Match
from scrapers.base_scraper import BaseScraper

class MatchScraper(BaseScraper):
    URL = "https://www.worldfootball.net/all_matches/eng-premier-league-2022-2023/"
    def fetch(self):
        html = requests.get(self.URL).text
        soup = BeautifulSoup(html, "html.parser")
        matches = []
        rows = soup.select("table.matches tr")[1:10]
        for r in rows:
            c = r.find_all("td")
            if len(c)>=6:
                score=c[3].text.split(":")
                matches.append(Match(c[0].text,c[2].text,c[4].text,int(score[0]),int(score[1])))
        return matches
