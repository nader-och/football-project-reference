# Football Match Analytics System

Reference project for grading.
Run with: python main.py
