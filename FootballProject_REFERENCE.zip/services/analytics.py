
class Analytics:
    def team_form(self,matches):
        table={}
        for m in matches:
            table.setdefault(m.home,0)
            table.setdefault(m.away,0)
            if m.home_goals>m.away_goals: table[m.home]+=3
            elif m.home_goals<m.away_goals: table[m.away]+=3
            else:
                table[m.home]+=1
                table[m.away]+=1
        return sorted(table.items(), key=lambda x:x[1], reverse=True)
